# Alex Qi 报价卡部署包

## 1. 后端部署到 Railway

上传 `backend` 文件夹里的全部文件到一个 GitHub 仓库，然后在 Railway:

1. New Project
2. Deploy from GitHub repo
3. 选择这个后端仓库
4. Variables 里添加：
   - `ANTHROPIC_API_KEY=你的 Anthropic API Key`
   - 可选：`ANTHROPIC_MODEL=claude-sonnet-4-20250514`
5. Settings / Networking 里 Generate Domain
6. 打开 Railway 域名，看到 `status: ok` 就成功

## 2. 前端部署到 GitHub Pages

前端文件是：

`frontend/alex_qi_quote_card.html`

部署前先把里面这一行：

```js
const BACKEND_URL = "https://YOUR-RAILWAY-DOMAIN.up.railway.app";
```

替换成你的 Railway 后端域名。

然后把这个 HTML 文件上传到你的前端 GitHub 仓库，作为 GitHub Pages 页面使用。

## 3. 结构

- `frontend/alex_qi_quote_card.html`：完整报价卡前端，已内嵌 eprimo 模板图片
- `backend/main.py`：FastAPI OCR 后端
- `backend/requirements.txt`：Python 依赖
- `backend/railway.toml`：Railway 启动配置
